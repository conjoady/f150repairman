/*
 * John Coady 
 * Westfield state university
 * cais 220
 */
package f150repairman;

import java.util.ArrayList;
import javafx.event.EventHandler;

//import java.beans.EventHandler;

import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;


public class mainhandler implements EventHandler<MouseEvent> 
{           
            ArrayList<Text> textlist;
            static ArrayList<Text> text0list = new ArrayList<>();
            static ArrayList<Text> outlist = new ArrayList<>();
            F150repairman refer = new F150repairman();
            
            
            
            public mainhandler(ArrayList<Text> list){
            textlist = list;
            
            text0list.add(0, new Text("Battery"));
                text0list.add(1, new Text("Alternator"));
                text0list.add(2, new Text("Starter"));
                text0list.add(3, new Text("Ignition Switch"));
                text0list.add(4, new Text("Battery Cable"));
            text0list.add(5, new Text("Brake Pads"));
                text0list.add(6, new Text("Brake rotors"));
                text0list.add(7, new Text("Brake calipers"));
                text0list.add(8, new Text("Brake master cylinder"));
                text0list.add(9, new Text("Brake fluid flush"));
            text0list.add(10, new Text("Headlight"));
                text0list.add(11, new Text("Doorlock actuator"));
                text0list.add(12, new Text("Motor mount"));
                text0list.add(13, new Text("Window lift motor"));
                text0list.add(14, new Text("Mirror assembly"));
            text0list.add(15, new Text("Waterpump"));
                text0list.add(16, new Text("Belt"));
                text0list.add(17, new Text("Radiator"));
                text0list.add(18, new Text("Thermostat"));
                text0list.add(19, new Text("AC compressor"));
                text0list.add(20, new Text("Coolant flush"));
            text0list.add(21, new Text("CV Axle"));
                text0list.add(22, new Text("Transmission flush/filter"));
                text0list.add(23, new Text("Transmission swap"));
                text0list.add(24, new Text("U-Joint"));
                text0list.add(25, new Text("Brake Pads"));
            text0list.add(26, new Text("Fuses"));
                text0list.add(27, new Text("Relays"));
                text0list.add(28, new Text("Brake Lights"));
                text0list.add(29, new Text("Interior dome lights"));
                text0list.add(30, new Text("Blinker bulbs"));
                text0list.add(31, new Text("Oxygen Sensor"));
                text0list.add(32, new Text("Muffler"));
                text0list.add(33, new Text("Catalytic converter"));
                text0list.add(34, new Text("Exhaust Pipe"));
                text0list.add(35, new Text("Exhuast manifold"));
                text0list.add(36, new Text("Mass airflow sensor"));
                text0list.add(37, new Text("Crankshaft position sensor"));
                text0list.add(38, new Text("Coolant temperature sensor"));
                text0list.add(39, new Text("Transmission speed sensor"));
                text0list.add(40, new Text("Throttle position sensor"));
                text0list.add(41, new Text("Engine control computer"));
                text0list.add(42, new Text("Spark Plug"));
                text0list.add(43, new Text("Oil Change/oil filter"));
                text0list.add(44, new Text("air filter"));
                text0list.add(45, new Text("Valve Cover gasket"));
                text0list.add(46, new Text("Motor swap"));
                text0list.add(47, new Text("Idler pulley"));
                text0list.add(48, new Text("Intake manifold"));
                text0list.add(49, new Text(""));
                text0list.add(50, new Text(""));
                text0list.add(51, new Text(""));
                text0list.add(52, new Text(""));
                text0list.add(53, new Text(""));
                text0list.add(54, new Text(""));
                text0list.add(55, new Text(""));
            
            }
            
            
    
       
     @Override
            public void handle(MouseEvent event) {
            
            if (event.getTarget().equals(textlist.get(0))){
                outlist.add(text0list.get(0));
                outlist.add(text0list.get(1));
                outlist.add(text0list.get(2));
                outlist.add(text0list.get(3));
                outlist.add(text0list.get(4));
                
            }    
                
            else if (event.getTarget().equals(textlist.get(1))){
                outlist.add(text0list.get(5));
                outlist.add(text0list.get(6));
                outlist.add(text0list.get(7));
                outlist.add(text0list.get(8));
                outlist.add(text0list.get(9));
                
            }
            else if (event.getTarget().equals(textlist.get(2))){
                outlist.add(text0list.get(10));
                outlist.add(text0list.get(11));
                outlist.add(text0list.get(12));
                outlist.add(text0list.get(13));
                outlist.add(text0list.get(14));
                
            }
            else if (event.getTarget().equals(textlist.get(3))){
                outlist.add(text0list.get(15));
                outlist.add(text0list.get(16));
                outlist.add(text0list.get(17));
                outlist.add(text0list.get(18));
                outlist.add(text0list.get(19));
                outlist.add(text0list.get(20));
                
            }
          
            else if (event.getTarget().equals(textlist.get(4))){
                outlist.add(text0list.get(21));
                outlist.add(text0list.get(22));
                outlist.add(text0list.get(23));
                outlist.add(text0list.get(24));
                outlist.add(text0list.get(25));
                
            }
            else if (event.getTarget().equals(textlist.get(5))){
                outlist.add(text0list.get(26));
                outlist.add(text0list.get(27));
                outlist.add(text0list.get(28));
                outlist.add(text0list.get(29));
                outlist.add(text0list.get(30));
                
            }
            else if (event.getTarget().equals(textlist.get(6))){
                outlist.add(text0list.get(31));
                outlist.add(text0list.get(32));
                outlist.add(text0list.get(33));
                outlist.add(text0list.get(34));
                outlist.add(text0list.get(35));
                
            }
            else if (event.getTarget().equals(textlist.get(7))){
                outlist.add(text0list.get(36));
                outlist.add(text0list.get(37));
                outlist.add(text0list.get(38));
                outlist.add(text0list.get(39));
                outlist.add(text0list.get(40));
                outlist.add(text0list.get(41));
                
            }
            else if (event.getTarget().equals(textlist.get(8))){
                outlist.add(text0list.get(42));
                outlist.add(text0list.get(43));
                outlist.add(text0list.get(44));
                outlist.add(text0list.get(45));
                outlist.add(text0list.get(46));
                outlist.add(text0list.get(47));
                outlist.add(text0list.get(48));
                
            }
            else if (event.getTarget().equals(textlist.get(9))){
                
            }
            else if (event.getTarget().equals(textlist.get(10))){
                
            }
            else if (event.getTarget().equals(textlist.get(11))){
                
            }
            else if (event.getTarget().equals(textlist.get(12))){
                
            }
            else if (event.getTarget().equals(textlist.get(13))){
                
            }
            else if (event.getTarget().equals(textlist.get(14))){
                
            }
            else if (event.getTarget().equals(textlist.get(15))){
                
            }
            else if (event.getTarget().equals(textlist.get(16))){
                
            }
            
            refer.setCenter(outlist);
            refer.changeHandler(new VideoHandler(text0list));
            
            }
        
        };

