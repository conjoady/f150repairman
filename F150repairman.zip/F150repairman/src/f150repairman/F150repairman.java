/*
 * John Coady 
 * Westfield state university
 * cais 220
 */
package f150repairman;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;


/**
 *
 * @author Home
 */
public class F150repairman extends Application {
    
    private static ArrayList<Text> mainlist = new ArrayList<>();
    private static VBox listpane = new VBox();
    
    public void F150repairman(){};
    
    @Override
    public void start(Stage primaryStage) {
        BorderPane borderpane = new BorderPane();
        Scene scene = new Scene(borderpane);
        ImageView topimage = new ImageView("images/lifted-ford-trucks.jpg");
        topimage.setFitHeight(200);
        topimage.setFitWidth(600);
        StackPane stackpane = new StackPane();
        stackpane.getChildren().add(topimage);
        borderpane.setTop(stackpane);
        ImageView bottomimage = new ImageView("images/rclogo_0.gif");
        bottomimage.setFitWidth(600);
        bottomimage.setFitHeight(150);
        StackPane bottomStack = new StackPane();
        bottomStack.getChildren().add(bottomimage);
        borderpane.setBottom(bottomStack);
        borderpane.setCenter(listpane);
        primaryStage.setTitle("F150 virtual repair guide");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        
        /**
         * Batteries, Starting And Charging
         * Brakes And Traction Control
         * Collision, Body Parts And Hardware
         * Cooling, Heating And Climate Control
         * Drivetrain
         * Electrical And Lighting
         * Emission Control And Exhaust
         * Engine Management
         * External Engine
         * Filters And PCV
         * Fuel Delivery
         * Gaskets
         * Ignition, Tune Up And Routine Maintenance
         * Interior
         * Internal Engine
         * Powertrain
         * Suspension, Steering, Tire And Wheel
         * Truck And Towing
         */
        
        Text text1 = new Text("Batteries, Starting And Charging");
        Text text2 = new Text("Brakes And Traction Control");
        Text text3 = new Text("Collision, Body Parts And Hardware");
        Text text4 = new Text("Cooling, Heating And Climate Control");
        Text text5 = new Text("Drivetrain");
        Text text6 = new Text("Electrical And Lighting");
        Text text7 = new Text("Emission Control And Exhaust");
        Text text8 = new Text("Engine Management");
        Text text9 = new Text("External Engine");
        Text text10 = new Text("Filters And PCV");
        Text text11 = new Text("Fuel Delivery");
        Text text12 = new Text("Gaskets");
        Text text13 = new Text("Ignition, Tune Up And Routine Maintenance");
        Text text14 = new Text("Interior");
        Text text15 = new Text("Internal Engine");
        Text text16 = new Text("Powertrain");
        Text text17 = new Text("Suspension, Steering, Tire And Wheel");
        Text text18 = new Text("Truck And Towing");
        
        mainlist.add(text1);
        mainlist.add(text2);
        mainlist.add(text3);
        mainlist.add(text4);
        mainlist.add(text5);
        mainlist.add(text6);
        mainlist.add(text7);
        mainlist.add(text8);
        mainlist.add(text9);
        mainlist.add(text10);
        mainlist.add(text11);
        mainlist.add(text12);
        mainlist.add(text13);
        mainlist.add(text14);
        mainlist.add(text15);
        mainlist.add(text16);
        mainlist.add(text17);
        
        
        listpane.getChildren().addAll(text1, text2, text3, text4, text5, text6, text7, text8, text9, text10,
                text11, text12, text13, text14, text15, text16, text17);
        listpane.setOnMouseClicked(new mainhandler(mainlist));
        
        
        
        
        
        
        
        
    }
    public void setCenter(ArrayList<Text> list0){
        listpane.getChildren().removeAll(mainlist);
        listpane.getChildren().addAll(list0);
        
    };
    public void changeHandler(EventHandler e){
        listpane.setOnMouseClicked(e);
    }
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
