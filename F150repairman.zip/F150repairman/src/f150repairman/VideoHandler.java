/*
 * John Coady 
 * Westfield state university
 * cais 220
 */
package f150repairman;

import java.util.ArrayList;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;


public class VideoHandler implements EventHandler<MouseEvent> {
    
    ArrayList<Text> list;
    
    public VideoHandler(ArrayList<Text> list0){
    list = list0;
    }
    
    @Override
    public void handle(MouseEvent event) {
        Node target = (Node)event.getTarget();
        
        
        
    
    }
    
}
